import { createClient } from '@supabase/supabase-js';
import './style.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;
const demoMode = !supabase;
const app = document.querySelector('#app');

const navItems = [
  ['home', '⌂', 'Início'],
  ['discover', '⌕', 'Descobrir atletas'],
  ['videos', '▶', 'Vídeos'],
  ['opportunities', '✦', 'Oportunidades'],
  ['clubs', '⚑', 'Clubes'],
  ['development', '◈', 'Meu desenvolvimento'],
  ['profile', '◉', 'Meu perfil']
];

const skills = [
  ['Técnica', 'Passe curto', 'Passe longo', 'Domínio de bola', 'Condução', 'Drible', 'Finalização', 'Cabeceio', 'Cruzamento'],
  ['Tática', 'Visão de jogo', 'Tomada de decisão', 'Posicionamento', 'Marcação', 'Cobertura', 'Movimentação sem bola', 'Transição ofensiva', 'Transição defensiva'],
  ['Físico e mental', 'Velocidade', 'Resistência', 'Agilidade', 'Equilíbrio', 'Força funcional', 'Concentração', 'Comunicação', 'Disciplina']
];

const demoPlayers = [
  { id: 'p1', display_name: 'Lucas M.', position: 'Atacante', category: 'Sub-15', dominant_foot: 'Destro', bio: 'Gosto de atacar espaço e finalizar de primeira.' },
  { id: 'p2', display_name: 'Rafa S.', position: 'Volante', category: 'Sub-14', dominant_foot: 'Canhoto', bio: 'Foco em passe, marcação e leitura de jogo.' },
  { id: 'p3', display_name: 'Caio R.', position: 'Goleiro', category: 'Sub-16', dominant_foot: 'Destro', bio: 'Trabalho em posicionamento e saída de gol.' },
  { id: 'p4', display_name: 'Davi P.', position: 'Ponta', category: 'Sub-15', dominant_foot: 'Ambidestro', bio: 'Velocidade, drible e participação ofensiva.' },
  { id: 'p5', display_name: 'Enzo L.', position: 'Zagueiro', category: 'Sub-17', dominant_foot: 'Destro', bio: 'Foco em antecipação e construção desde trás.' },
  { id: 'p6', display_name: 'Gui A.', position: 'Meia ofensivo', category: 'Sub-14', dominant_foot: 'Canhoto', bio: 'Criatividade, passe entre linhas e assistência.' }
];

const demoPosts = [
  { id: 'demo1', user_id: 'p1', caption: 'Trabalho de finalização e movimentação. Evoluindo um lance de cada vez.', created_at: new Date(Date.now() - 3600000).toISOString(), profiles: demoPlayers[0], demoLabel: 'LANCE DEMONSTRATIVO' },
  { id: 'demo2', user_id: 'p2', caption: 'Treino de passe e leitura antes de receber a bola.', created_at: new Date(Date.now() - 8200000).toISOString(), profiles: demoPlayers[1], demoLabel: 'TREINO DEMONSTRATIVO' },
  { id: 'demo3', user_id: 'p4', caption: 'Condução curta e mudança de direção no espaço reduzido.', created_at: new Date(Date.now() - 19000000).toISOString(), profiles: demoPlayers[3], demoLabel: 'TREINO DEMONSTRATIVO' }
];

const demoClubs = [
  { id: 'club1', name: 'Atlético Horizonte', description: 'Perfil fictício de demonstração para mostrar como clubes e suas informações poderão aparecer.', badge_url: null },
  { id: 'club2', name: 'União da Base', description: 'Clube de exemplo. Não representa uma equipe real nem oferece seletivas.', badge_url: null },
  { id: 'club3', name: 'Esporte Futuro', description: 'Página ilustrativa de clube com foco em categorias de formação.', badge_url: null }
];

const demoOpportunities = [
  { id: 'opp1', title: 'Avaliação técnica — exemplo', position: 'Meio-campo', category: 'Sub-15', description: 'Card de demonstração. Não é uma seletiva real e não aceita inscrições.', clubs: { name: 'Atlético Horizonte' } },
  { id: 'opp2', title: 'Observação de atletas — exemplo', position: 'Atacante', category: 'Sub-14', description: 'Exemplo visual de oportunidade. Consulte sempre os canais oficiais dos clubes.', clubs: { name: 'União da Base' } }
];

let session = null;
let currentPage = 'home';
let localProfile = loadLocalProfile();
let localLikes = loadLocalLikes();
let cachedFeed = [];
let searchTerm = '';

function loadLocalProfile() {
  try {
    return { display_name: 'Meu perfil', position: 'Volante', category: 'Sub-15', dominant_foot: 'Destro', bio: 'Meu objetivo é evoluir no futebol.', skills: {}, ...JSON.parse(localStorage.getItem('scoutplay_demo_profile') || '{}') };
  } catch { return { display_name: 'Meu perfil', position: 'Volante', category: 'Sub-15', dominant_foot: 'Destro', bio: 'Meu objetivo é evoluir no futebol.', skills: {} }; }
}
function loadLocalLikes() { try { return JSON.parse(localStorage.getItem('scoutplay_demo_likes') || '{}'); } catch { return {}; } }
function saveLocalProfile() { localStorage.setItem('scoutplay_demo_profile', JSON.stringify(localProfile)); }
function esc(value = '') {
  return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function initials(name = 'Atleta') { return esc(name.trim().split(/\s+/).slice(0, 2).map(x => x[0] || '').join('').toUpperCase()); }
function dateLabel(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recentemente';
  return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' }).format(date);
}
function profileCompletion(profile) {
  const fields = ['display_name', 'position', 'category', 'dominant_foot', 'bio'];
  return Math.round(fields.filter(k => String(profile?.[k] || '').trim()).length / fields.length * 100);
}
function activeProfile() { return localProfile; }

function shell(content, page = currentPage) {
  const nav = navItems.map(([id, icon, label]) => `<button class="nav-link ${page === id ? 'active' : ''}" data-page="${id}" aria-label="${label}"><span class="nav-icon">${icon}</span><span>${label}</span></button>`).join('');
  const miniProfile = activeProfile();
  app.innerHTML = `
    <header class="topbar">
      <a class="brand" href="#" data-page="home"><span class="brand-mark">S</span><span>SCOUT<span>PLAY</span></span></a>
      <form class="top-search" id="global-search"><span>⌕</span><input id="global-search-input" placeholder="Buscar atletas, posições..." value="${esc(searchTerm)}" aria-label="Buscar"></form>
      <div class="top-actions">
        ${demoMode ? '<span class="demo-pill">MODO DEMO</span><button class="outline-btn demo-signup" data-page="signup">Criar conta</button>' : session ? `<span class="top-user">${esc(session.user.email || 'Atleta')}</span><button class="icon-btn" id="logout" title="Sair">↪</button>` : '<button class="ghost-btn" data-page="login">Entrar</button>'}
        ${!session && !demoMode ? '<button class="primary-btn top-cta" data-page="signup">Criar conta</button>' : ''}
        <button class="top-menu-btn" id="top-menu" aria-label="Mais opções">☰</button>
      </div>
    </header>
    <div class="app-layout">
      <aside class="left-rail">
        <button class="create-btn" data-page="upload"><span>＋</span> Publicar vídeo</button>
        <div class="nav-caption">MENU PRINCIPAL</div>
        <nav class="side-nav">${nav}</nav>
        <div class="rail-profile">
          <div class="avatar">${initials(miniProfile.display_name)}</div>
          <div class="rail-profile-text"><b>${esc(miniProfile.display_name)}</b><small>${esc(miniProfile.position)} · ${esc(miniProfile.category)}</small></div>
          <button data-page="profile" class="tiny-arrow" aria-label="Abrir perfil">›</button>
        </div>
        <div class="safety-note"><b>Jogue com segurança</b><p>Não publique escola, endereço, telefone, rotina ou localização em tempo real. Peça ajuda a um responsável.</p></div>
      </aside>
      <main class="main-content">
        ${demoMode ? '<div class="demo-banner"><b>Prévia demonstrativa</b><span>Conteúdo fictício. Cadastro, publicações e dados reais só funcionam depois de conectar o banco e publicar o site.</span></div>' : ''}
        ${content}
      </main>
      <aside class="right-rail">
        <section class="side-card profile-progress"><div class="side-card-head"><b>Seu perfil esportivo</b><button data-page="profile">Editar</button></div><div class="progress-number">${profileCompletion(miniProfile)}<small>% completo</small></div><div class="progress-track"><span style="width:${profileCompletion(miniProfile)}%"></span></div><p>Complete suas informações esportivas para apresentar melhor seu futebol.</p></section>
        <section class="side-card quick-links"><b>Explore o ScoutPlay</b><button data-page="opportunities"><span>✦</span> Oportunidades</button><button data-page="clubs"><span>⚑</span> Clubes</button><button data-page="development"><span>◈</span> Desenvolvimento</button></section>
        <div class="right-footnote">SCOUTPLAY · Plataforma independente<br>Não afiliada ao Footbao.</div>
      </aside>
    </div>
    <nav class="mobile-nav">
      <button data-page="home" class="${page === 'home' ? 'active' : ''}"><span>⌂</span>Início</button>
      <button data-page="discover" class="${page === 'discover' ? 'active' : ''}"><span>⌕</span>Atletas</button>
      <button data-page="upload" class="mobile-add"><span>＋</span></button>
      <button data-page="opportunities" class="${page === 'opportunities' ? 'active' : ''}"><span>✦</span>Vagas</button>
      <button data-page="profile" class="${page === 'profile' ? 'active' : ''}"><span>◉</span>Perfil</button>
    </nav>`;

  app.querySelectorAll('[data-page]').forEach(el => el.addEventListener('click', e => { e.preventDefault(); go(el.dataset.page); }));
  const searchForm = app.querySelector('#global-search');
  searchForm?.addEventListener('submit', e => { e.preventDefault(); searchTerm = app.querySelector('#global-search-input').value.trim(); go('discover'); });
  const logout = app.querySelector('#logout');
  if (logout) logout.onclick = async () => { await supabase.auth.signOut(); session = null; go('home'); };
  const topMenu = app.querySelector('#top-menu');
  if (topMenu) topMenu.onclick = () => showModal('Mais opções', `<div class="modal-menu"><button data-modal-page="videos">▶ Vídeos da comunidade</button><button data-modal-page="clubs">⚑ Clubes</button><button data-modal-page="development">◈ Meu desenvolvimento</button><button data-modal-page="upload">＋ Publicar vídeo</button></div>`);
}

function pageHeading(kicker, title, desc = '') {
  return `<div class="page-heading"><div><span class="eyebrow">${esc(kicker)}</span><h1>${esc(title)}</h1>${desc ? `<p>${esc(desc)}</p>` : ''}</div></div>`;
}
function playerCard(player) {
  return `<article class="player-card"><div class="player-card-top"><div class="avatar large">${initials(player.display_name)}</div><span class="online-dot" title="Perfil público"></span></div><h3>${esc(player.display_name || 'Atleta')}</h3><p class="player-role">${esc(player.position || 'Posição não informada')} <span>·</span> ${esc(player.category || 'Categoria não informada')}</p><div class="player-tags"><span>${esc(player.dominant_foot || 'Pé não informado')}</span></div><p class="player-bio">${esc(player.bio || 'Atleta da comunidade ScoutPlay.')}</p><button class="text-action" data-player="${esc(player.id)}">Ver perfil <span>→</span></button></article>`;
}
function postCard(post, index = 0) {
  const author = post.profiles || {};
  const liked = demoMode ? !!localLikes[post.id] : !!post.liked_by_me;
  const count = Number(post.like_count || 0) + (demoMode && liked ? 1 : 0);
  const video = post.video_url ? `<video class="post-video" controls playsinline preload="metadata" src="${esc(post.video_url)}"></video>` : `<div class="video-placeholder tone-${index % 3}"><div class="pitch-lines"></div><span class="play-mark">▶</span><b>${esc(post.demoLabel || 'VÍDEO AGUARDANDO REVISÃO')}</b><small>${demoMode ? 'Prévia visual • sem vídeo real' : 'Prévia do lance'}</small></div>`;
  return `<article class="post-card" data-post="${esc(post.id)}">
    <div class="post-author"><div class="avatar">${initials(author.display_name || 'Atleta')}</div><div class="author-info"><b>${esc(author.display_name || 'Atleta')}</b><span>${esc(author.position || 'Jogador')} · ${esc(author.category || '')}</span></div><time>${dateLabel(post.created_at)}</time></div>
    <p class="post-caption">${esc(post.caption || '')}</p>
    ${video}
    <div class="post-actions"><button class="post-action ${liked ? 'liked' : ''}" data-like="${esc(post.id)}"><span>${liked ? '♥' : '♡'}</span> ${count ? count + ' curtidas' : 'Curtir'}</button><button class="post-action" data-comment="${esc(post.id)}"><span>▢</span> Comentar</button><span class="post-approved">${demoMode ? 'EXEMPLO' : 'APROVADO'}</span></div>
    <div class="comment-area" id="comments-${esc(post.id)}" hidden><div class="comment-list">${(post.comments || []).map(c => `<p><b>${esc(c.profiles?.display_name || 'Atleta')}</b> ${esc(c.body)}</p>`).join('') || '<small>Seja respeitoso e comente sobre o futebol.</small>'}</div><form class="comment-form" data-comment-form="${esc(post.id)}"><input name="body" maxlength="240" placeholder="Escreva um comentário..." required><button>Enviar</button></form><small class="comment-note">Comentários enviados passam por revisão antes de aparecer.</small></div>
  </article>`;
}

async function getPosts() {
  if (demoMode) return demoPosts;
  const { data, error } = await supabase.from('posts').select('id,caption,video_path,created_at,user_id,profiles(display_name,position,category),post_comments(id,body,created_at,profiles(display_name))').eq('moderation_status', 'approved').order('created_at', { ascending: false }).limit(25);
  if (error) return [];
  const posts = await Promise.all((data || []).map(async p => {
    const { data: signed } = await supabase.storage.from('football-videos').createSignedUrl(p.video_path, 1800);
    let liked = false;
    let like_count = 0;
    if (session) {
      const own = await supabase.from('post_likes').select('post_id').eq('post_id', p.id).eq('user_id', session.user.id).maybeSingle();
      liked = !!own.data;
    }
    const count = await supabase.rpc('get_post_like_count', { target_post: p.id });
    like_count = Number(count.data || 0);
    return { ...p, video_url: signed?.signedUrl || null, liked_by_me: liked, like_count };
  }));
  return posts;
}
async function loadFeed(container) {
  const el = container || app.querySelector('#feed-list');
  if (!el) return;
  el.innerHTML = '<div class="loading-card">Carregando publicações...</div>';
  cachedFeed = await getPosts();
  el.innerHTML = cachedFeed.map(postCard).join('') || '<div class="empty-state"><span>⚽</span><h3>O feed está começando</h3><p>Quando houver vídeos aprovados, eles aparecerão aqui.</p></div>';
  bindPostActions(el);
}
function bindPostActions(root) {
  root.querySelectorAll('[data-like]').forEach(btn => btn.onclick = async () => {
    const id = btn.dataset.like;
    if (demoMode) {
      localLikes[id] = !localLikes[id];
      localStorage.setItem('scoutplay_demo_likes', JSON.stringify(localLikes));
      await loadFeed(root);
      return;
    }
    if (!session) { go('login'); return; }
    const result = await supabase.rpc('toggle_post_like', { target_post: id });
    if (result.error) { alert(result.error.message); return; }
    const item = cachedFeed.find(p => p.id === id);
    if (item) { item.liked_by_me = !!result.data?.liked; item.like_count = Number(result.data?.like_count || 0); }
    await loadFeed(root);
  });
  root.querySelectorAll('[data-comment]').forEach(btn => btn.onclick = () => {
    const el = root.querySelector(`#comments-${CSS.escape(btn.dataset.comment)}`);
    if (el) el.hidden = !el.hidden;
  });
  root.querySelectorAll('[data-comment-form]').forEach(form => form.onsubmit = async e => {
    e.preventDefault();
    const body = new FormData(form).get('body').toString().trim();
    if (!body) return;
    if (demoMode) { alert('Na prévia, comentários não são publicados. Conecte o banco para ativar esse recurso.'); return; }
    if (!session) { go('login'); return; }
    const r = await supabase.from('post_comments').insert({ post_id: form.dataset.commentForm, user_id: session.user.id, body, moderation_status: 'pending' });
    alert(r.error ? r.error.message : 'Comentário enviado para revisão.');
    form.reset();
  });
}

async function go(page) {
  currentPage = page;
  if (!demoMode && ['profile', 'upload', 'development'].includes(page) && !session) { go('login'); return; }

  if (page === 'home') {
    shell(`${pageHeading('COMUNIDADE DE FUTEBOL', 'Seu jogo merece destaque.', 'Compartilhe sua evolução, acompanhe atletas e encontre oportunidades com segurança.')}<section class="welcome-panel"><div><span class="eyebrow">SCOUTPLAY · REDE DE TALENTOS</span><h2>Do treino ao próximo desafio.</h2><p>Um espaço para organizar seu perfil esportivo e mostrar seu futebol.</p><button class="primary-btn" data-page="profile">Montar meu perfil <span>→</span></button></div><div class="welcome-graphic"><div class="graphic-ball">⚽</div><div class="graphic-stats"><b>SEU FUTEBOL</b><span>SEU CAMINHO</span></div></div></section><div class="section-title"><div><span class="eyebrow">COMUNIDADE</span><h2>Feed de talentos</h2></div><button class="text-action" data-page="videos">Ver todos <span>→</span></button></div><div id="feed-list" class="feed-list"></div>`, page);
    loadFeed(); return;
  }

  if (page === 'videos') {
    shell(`${pageHeading('VÍDEOS DA COMUNIDADE', 'Destaques em campo', 'Assista aos lances que passaram pela revisão da comunidade.')}<div class="feed-toolbar"><span>Mais recentes</span><span class="safe-chip">Conteúdo moderado</span></div><div id="feed-list" class="feed-list"></div>`, page);
    loadFeed(); return;
  }

  if (page === 'discover') {
    shell(`${pageHeading('REDE DE ATLETAS', 'Descobrir jogadores', 'Explore perfis esportivos e encontre atletas por posição e categoria.')}<div class="filter-bar"><input id="player-filter" placeholder="Buscar por nome, posição ou categoria..." value="${esc(searchTerm)}"><select id="position-filter"><option value="">Todas as posições</option>${['Goleiro','Zagueiro','Lateral','Volante','Meio-campo','Meia ofensivo','Ponta','Atacante'].map(x => `<option>${x}</option>`).join('')}</select></div><div id="player-grid" class="player-grid"><div class="loading-card">Carregando atletas...</div></div>`, page);
    let players = demoMode ? demoPlayers : (await supabase.from('profiles').select('id,display_name,position,category,dominant_foot,bio').order('created_at', { ascending: false }).limit(60)).data || [];
    const grid = app.querySelector('#player-grid');
    const filter = () => {
      const term = app.querySelector('#player-filter').value.toLowerCase();
      const pos = app.querySelector('#position-filter').value;
      const filtered = players.filter(p => `${p.display_name} ${p.position} ${p.category}`.toLowerCase().includes(term) && (!pos || p.position === pos));
      grid.innerHTML = filtered.map(playerCard).join('') || '<div class="empty-state"><h3>Nenhum atleta encontrado</h3><p>Tente outro nome ou filtro.</p></div>';
      grid.querySelectorAll('[data-player]').forEach(btn => btn.onclick = () => { const p = filtered.find(x => x.id === btn.dataset.player); if (p) showModal('Perfil esportivo', `<div class="modal-profile"><div class="avatar large">${initials(p.display_name)}</div><h3>${esc(p.display_name)}</h3><p>${esc(p.position)} · ${esc(p.category)} · ${esc(p.dominant_foot || 'Pé não informado')}</p><div class="modal-note">${esc(p.bio || 'Atleta da comunidade ScoutPlay.')}</div><small>Perfil de demonstração ou perfil esportivo público. Não compartilhe dados pessoais.</small></div>`); });
    };
    app.querySelector('#player-filter').oninput = filter;
    app.querySelector('#position-filter').onchange = filter;
    filter(); return;
  }

  if (page === 'opportunities') {
    shell(`${pageHeading('PRÓXIMOS PASSOS', 'Oportunidades', 'Acompanhe oportunidades publicadas por clubes verificados. Confira sempre os detalhes nos canais oficiais.')}<div class="notice-strip"><b>Importante:</b> o ScoutPlay não garante testes ou contratação. Nunca pague alguém para prometer uma vaga.</div><div id="opportunity-list" class="opportunity-list"><div class="loading-card">Carregando oportunidades...</div></div><div class="section-title applications-title"><div><span class="eyebrow">ACOMPANHAMENTO</span><h2>Minhas candidaturas</h2></div></div><div id="my-applications" class="application-list"></div>`, page);
    const items = demoMode ? demoOpportunities : (await supabase.from('opportunities').select('id,title,position,category,description,closes_at,clubs(name,verified)').eq('is_active', true).order('created_at', { ascending: false })).data || [];
    const list = app.querySelector('#opportunity-list');
    list.innerHTML = items.map(o => `<article class="opportunity-card"><div class="opportunity-icon">✦</div><div class="opportunity-content"><div class="opportunity-meta"><span>${esc(o.clubs?.name || 'Clube')}</span><span>${demoMode ? 'EXEMPLO' : 'CLUBE VERIFICADO'}</span></div><h3>${esc(o.title)}</h3><div class="opportunity-tags"><span>${esc(o.position)}</span><span>${esc(o.category)}</span>${o.closes_at ? `<span>Até ${dateLabel(o.closes_at)}</span>` : ''}</div><p>${esc(o.description)}</p><button class="outline-btn" data-opportunity="${esc(o.id)}">${demoMode ? 'Ver exemplo' : 'Ver oportunidade'} <span>→</span></button></div></article>`).join('') || '<div class="empty-state"><span>✦</span><h3>Nenhuma oportunidade aberta</h3><p>Novas oportunidades verificadas poderão aparecer aqui.</p></div>';
    list.querySelectorAll('[data-opportunity]').forEach(b => b.onclick = async () => {
      const opportunity = items.find(o => o.id === b.dataset.opportunity);
      if (demoMode) { showModal('Oportunidade demonstrativa', `<p>${esc(opportunity?.description || 'Exemplo visual')}</p><div class="privacy-inline">Esta oportunidade é fictícia. Não existe seletiva, clube participante ou inscrição real.</div>`); return; }
      if (!session) { go('login'); return; }
      showModal('Candidatura à oportunidade', `<p><b>${esc(opportunity?.title || 'Oportunidade')}</b></p><p class="modal-muted">${esc(opportunity?.clubs?.name || 'Clube verificado')} · ${esc(opportunity?.position || '')} · ${esc(opportunity?.category || '')}</p><form id="application-form"><label>Mensagem esportiva (opcional)<textarea name="note" maxlength="500" placeholder="Apresente brevemente seu interesse sem incluir telefone, endereço ou escola."></textarea></label><div class="privacy-inline">O envio só será aceito se a aprovação do responsável estiver registrada. A candidatura não garante avaliação ou vaga.</div><button class="primary-btn" type="submit">Enviar candidatura</button></form>`);
      const form = app.querySelector('#application-form');
      form.onsubmit = async e => {
        e.preventDefault();
        const note = new FormData(form).get('note').toString().trim();
        const r = await supabase.from('opportunity_applications').insert({ opportunity_id: opportunity.id, user_id: session.user.id, note });
        if (r.error) { toast(r.error.message.includes('duplicate') ? 'Você já enviou uma candidatura para esta oportunidade.' : r.error.message); return; }
        closeModal(); toast('Candidatura enviada. Acompanhe as atualizações pela plataforma.');
      };
    });
    const applicationArea = app.querySelector('#my-applications');
    if (demoMode) {
      applicationArea.innerHTML = '<div class="empty-state compact-empty">Entre com uma conta configurada e aprovada para acompanhar candidaturas reais.</div>';
    } else if (!session) {
      applicationArea.innerHTML = '<div class="empty-state compact-empty">Entre na sua conta para acompanhar suas candidaturas.</div>';
    } else {
      const { data: applications, error: applicationsError } = await supabase.from('opportunity_applications').select('id,status,created_at,opportunities(title,position,category,clubs(name))').eq('user_id', session.user.id).order('created_at', { ascending: false }).limit(20);
      const labels = { received: 'Recebida', reviewing: 'Em análise', contacted: 'Contato realizado', closed: 'Encerrada' };
      applicationArea.innerHTML = applicationsError ? '<div class="empty-state compact-empty">Não foi possível carregar suas candidaturas.</div>' : (applications || []).map(a => `<article class="application-row"><div><b>${esc(a.opportunities?.title || 'Oportunidade')}</b><span>${esc(a.opportunities?.clubs?.name || 'Clube')} · ${esc(a.opportunities?.position || '')} · ${dateLabel(a.created_at)}</span></div><em class="application-status status-${esc(a.status)}">${esc(labels[a.status] || 'Recebida')}</em></article>`).join('') || '<div class="empty-state compact-empty">Você ainda não enviou candidaturas.</div>';
    }
    return;
  }

  if (page === 'clubs') {
    shell(`${pageHeading('CONHEÇA AS EQUIPES', 'Clubes', 'Páginas de clubes com informações e oportunidades verificadas.')}<div id="club-grid" class="club-grid"><div class="loading-card">Carregando clubes...</div></div>`, page);
    const clubs = demoMode ? demoClubs : (await supabase.from('clubs').select('id,name,description,badge_url').eq('verified', true).eq('is_active', true).order('name')).data || [];
    app.querySelector('#club-grid').innerHTML = clubs.map(c => `<article class="club-card"><div class="club-badge">${c.badge_url ? `<img src="${esc(c.badge_url)}" alt="">` : '⚑'}</div><div class="club-card-content"><span class="verified-label">${demoMode ? 'PERFIL DE EXEMPLO' : '✓ PERFIL VERIFICADO'}</span><h3>${esc(c.name)}</h3><p>${esc(c.description || 'Informações do clube e suas oportunidades.')}</p><button class="text-action" data-club="${esc(c.id)}">Ver clube <span>→</span></button></div></article>`).join('') || '<div class="empty-state"><span>⚑</span><h3>Clubes em breve</h3><p>Os perfis aparecerão depois da verificação da plataforma.</p></div>';
    app.querySelectorAll('[data-club]').forEach(b => b.onclick = () => { const c = clubs.find(x => x.id === b.dataset.club); if (c) showModal(c.name, `<div class="club-modal-badge">⚑</div><p>${esc(c.description || 'Informações do clube.')}</p><div class="privacy-inline">${demoMode ? 'Perfil fictício para demonstração. Não representa um clube real.' : 'Perfil de clube verificado pela administração do ScoutPlay.'}</div>`); });
    return;
  }

  if (page === 'development') {
    const profile = await getMyProfile();
    const values = profile.skills || {};
    shell(`${pageHeading('ACOMPANHE SUA EVOLUÇÃO', 'Meu desenvolvimento', 'Faça uma autoavaliação para acompanhar seus treinos. Isso não é uma avaliação profissional nem uma análise de olheiro.')}<div class="self-rating-banner"><span>◈</span><div><b>Autoavaliação esportiva</b><p>Escolha uma nota de 1 a 5 conforme sua percepção atual. Refaça depois de um período de treino para comparar sua evolução.</p></div></div><form id="skills-form" class="skills-form">${skills.map((group, gi) => `<section class="skill-group"><div class="skill-group-title"><span>0${gi + 1}</span><h2>${group[0]}</h2></div><div class="skill-grid">${group.slice(1).map(s => `<label class="skill-item"><span>${esc(s)}</span><select name="${esc(s)}"><option value="">Não avaliado</option>${[1,2,3,4,5].map(n => `<option value="${n}" ${String(values[s] || '') === String(n) ? 'selected' : ''}>${n} · ${['','Iniciando','Em evolução','Consistente','Forte','Muito forte'][n]}</option>`).join('')}</select></label>`).join('')}</div></section>`).join('')}<button class="primary-btn" type="submit">Salvar minha autoavaliação</button><p class="form-footnote">Use como registro pessoal, não como comparação definitiva com outros jogadores.</p></form>`, page);
    app.querySelector('#skills-form').onsubmit = async e => {
      e.preventDefault();
      const form = new FormData(e.currentTarget); const newSkills = {};
      for (const [k, v] of form.entries()) if (v) newSkills[k] = Number(v);
      if (demoMode) { localProfile.skills = newSkills; saveLocalProfile(); toast('Autoavaliação salva neste navegador.'); }
      else { const r = await supabase.from('profiles').update({ skills: newSkills }).eq('id', session.user.id); toast(r.error ? r.error.message : 'Autoavaliação salva.'); }
    };
    return;
  }

  if (page === 'profile') {
    const profile = await getMyProfile();
    shell(`${pageHeading('IDENTIDADE ESPORTIVA', 'Meu perfil', 'Organize suas informações de futebol sem expor dados pessoais.')}<section class="profile-cover"><div class="profile-cover-avatar">${initials(profile.display_name)}</div><div><span class="eyebrow">PERFIL DE ATLETA</span><h2>${esc(profile.display_name)}</h2><p>${esc(profile.position)} · ${esc(profile.category)} · ${esc(profile.dominant_foot)}</p></div><span class="profile-completion">${profileCompletion(profile)}% completo</span></section><form id="profile-form" class="profile-form"><div class="form-section-head"><h2>Informações esportivas</h2><span>Visíveis no perfil</span></div><div class="form-grid"><label>Nome de exibição / apelido<input id="display_name" maxlength="40" minlength="2" value="${esc(profile.display_name)}" required></label><label>Posição principal<select id="position">${['Goleiro','Zagueiro','Lateral','Volante','Meio-campo','Meia ofensivo','Ponta','Atacante'].map(v => `<option ${profile.position === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label>Categoria<select id="category">${['Sub-13','Sub-14','Sub-15','Sub-16','Sub-17','Sub-18','Sub-20','Adulto'].map(v => `<option ${profile.category === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label><label>Pé dominante<select id="dominant_foot">${['Destro','Canhoto','Ambidestro'].map(v => `<option ${profile.dominant_foot === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label></div><label>Sobre seu futebol<textarea id="bio" maxlength="400" placeholder="Conte sua posição, características e objetivos esportivos.">${esc(profile.bio)}</textarea></label><div class="privacy-inline">🔒 Não inclua nome completo, data de nascimento, telefone, escola, endereço ou horários de treino.</div><button class="primary-btn" type="submit">Salvar alterações</button></form>`, page);
    app.querySelector('#profile-form').onsubmit = async e => {
      e.preventDefault();
      const payload = { display_name: app.querySelector('#display_name').value.trim(), position: app.querySelector('#position').value, category: app.querySelector('#category').value, dominant_foot: app.querySelector('#dominant_foot').value, bio: app.querySelector('#bio').value.trim() };
      if (demoMode) { localProfile = { ...localProfile, ...payload }; saveLocalProfile(); toast('Perfil salvo apenas nesta demonstração.'); go('profile'); }
      else { const r = await supabase.from('profiles').update(payload).eq('id', session.user.id); toast(r.error ? r.error.message : 'Perfil atualizado.'); if (!r.error) go('profile'); }
    };
    return;
  }

  if (page === 'upload') {
    if (!demoMode && !session) { go('login'); return; }
    shell(`${pageHeading('COMPARTILHE SEU JOGO', 'Publicar vídeo', 'Envie um lance ou treino para revisão antes de aparecer no feed.')}<section class="upload-card"><div class="upload-icon">＋</div><h2>Mostre um lance seu</h2><p>Escolha um vídeo curto, escreva uma legenda e envie para revisão.</p><div class="upload-rules"><span>MP4 ou WebM</span><span>Até 50 MB</span><span>Revisão antes de publicar</span></div><form id="upload-form"><label class="file-drop"><span>⇧</span><b>Selecionar vídeo</b><small>Toque para escolher um arquivo do dispositivo</small><input type="file" id="video-file" accept="video/mp4,video/webm" required></label><div id="file-name" class="file-name"></div><label>Legenda<textarea id="caption" maxlength="500" placeholder="Conte sobre o lance, sem divulgar local ou rotina."></textarea></label><div class="privacy-inline">Vídeos enviados ficam privados até passarem pela revisão. Para contas de menores, é necessária a aprovação do responsável.</div><button class="primary-btn" type="submit">Enviar para revisão <span>→</span></button></form></section>`, page);
    const fileInput = app.querySelector('#video-file');
    fileInput.onchange = () => { app.querySelector('#file-name').textContent = fileInput.files[0]?.name || ''; };
    app.querySelector('#upload-form').onsubmit = async e => {
      e.preventDefault();
      if (demoMode) { toast('Prévia demonstrativa: conecte o Supabase para enviar vídeos reais.'); return; }
      const file = fileInput.files[0];
      if (!file || file.size > 50 * 1024 * 1024) { toast('Escolha um vídeo de até 50 MB.'); return; }
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const path = `${session.user.id}/${crypto.randomUUID()}-${safeName}`;
      const uploaded = await supabase.storage.from('football-videos').upload(path, file);
      if (uploaded.error) { toast(uploaded.error.message); return; }
      const inserted = await supabase.from('posts').insert({ user_id: session.user.id, caption: app.querySelector('#caption').value.trim(), video_path: path, moderation_status: 'pending' });
      if (inserted.error) { toast(inserted.error.message); return; }
      toast('Vídeo enviado para revisão.'); go('profile');
    };
    return;
  }

  if (page === 'login' || page === 'signup') {
    const signup = page === 'signup';
    shell(`${pageHeading('ACESSO SCOUTPLAY', signup ? 'Crie sua conta' : 'Bem-vindo de volta', signup ? 'Crie um perfil esportivo para começar.' : 'Entre para acessar seu espaço de atleta.')}<section class="auth-card"><form id="auth-form"><label>E-mail<input id="email" type="email" required autocomplete="email"></label><label>Senha<input id="password" type="password" minlength="8" required autocomplete="${signup ? 'new-password' : 'current-password'}"></label>${signup ? '<label>Apelido esportivo<input id="display" maxlength="40" minlength="2" required></label><p class="form-footnote">Se você é menor de 18 anos, converse com seu responsável antes de criar uma conta ou compartilhar conteúdo.</p>' : ''}<button class="primary-btn" type="submit">${signup ? 'Criar conta' : 'Entrar'}</button></form><p class="auth-switch">${signup ? 'Já tem conta?' : 'Ainda não tem conta?'} <button data-page="${signup ? 'login' : 'signup'}">${signup ? 'Entrar' : 'Criar conta'}</button></p>${demoMode ? '<div class="demo-auth-note">Esta é uma prévia. O cadastro real só ficará ativo depois de configurar o Supabase.</div>' : ''}</section>`, page);
    app.querySelector('#auth-form').onsubmit = async e => {
      e.preventDefault();
      if (demoMode) { toast('Cadastro de demonstração. Configure o banco para criar uma conta real.'); return; }
      const email = app.querySelector('#email').value; const password = app.querySelector('#password').value;
      const result = signup ? await supabase.auth.signUp({ email, password, options: { data: { display_name: app.querySelector('#display').value.trim() } } }) : await supabase.auth.signInWithPassword({ email, password });
      if (result.error) toast(result.error.message);
      else if (signup) toast('Confira seu e-mail para confirmar o cadastro.');
      else { session = result.data.session; go('home'); }
    };
    return;
  }

  go('home');
}

async function getMyProfile() {
  if (demoMode) return localProfile;
  const { data } = await supabase.from('profiles').select('id,display_name,position,category,dominant_foot,bio,skills,created_at').eq('id', session.user.id).single();
  return data || { display_name: 'Atleta', position: 'Meio-campo', category: 'Sub-15', dominant_foot: 'Destro', bio: '', skills: {} };
}
function toast(message) {
  const old = document.querySelector('.toast'); old?.remove();
  const el = document.createElement('div'); el.className = 'toast'; el.textContent = message; document.body.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function showModal(title, body) {
  closeModal();
  const modal = document.createElement('div');
  modal.className = 'modal-backdrop';
  modal.id = 'active-modal';
  modal.innerHTML = `<section class="modal-card" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-head"><h2>${esc(title)}</h2><button type="button" class="modal-close" data-modal-close aria-label="Fechar">×</button></div><div class="modal-body">${body}</div></section>`;
  modal.addEventListener('click', e => { if (e.target === modal || e.target.closest('[data-modal-close]')) closeModal(); });
  modal.querySelectorAll('[data-modal-page]').forEach(btn => btn.addEventListener('click', () => { const destination = btn.dataset.modalPage; closeModal(); go(destination); }));
  app.appendChild(modal);
}
function closeModal() { document.querySelector('#active-modal')?.remove(); }

async function init() {
  if (!demoMode) {
    const { data } = await supabase.auth.getSession(); session = data.session;
    supabase.auth.onAuthStateChange((_event, next) => { session = next; });
  }
  go('home');
}
init();
