-- SCOUTPLAY — esquema inicial do banco (Supabase)
-- Execute no SQL Editor de um projeto Supabase novo.
-- O projeto usa RLS. Nunca coloque a chave service_role no frontend.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  position text not null default 'Meio-campo',
  category text not null default 'Sub-15',
  dominant_foot text not null default 'Destro',
  bio text not null default '' check (char_length(bio) <= 400),
  skills jsonb not null default '{}'::jsonb,
  guardian_approved boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.profiles add column if not exists skills jsonb not null default '{}'::jsonb;

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '' check (char_length(caption) <= 500),
  video_path text not null,
  moderation_status text not null default 'pending'
    check (moderation_status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.post_likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists public.post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 240),
  moderation_status text not null default 'pending'
    check (moderation_status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  description text not null default '' check (char_length(description) <= 700),
  badge_url text,
  verified boolean not null default false,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 100),
  position text not null,
  category text not null,
  description text not null default '' check (char_length(description) <= 1000),
  closes_at timestamptz,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.opportunity_applications (
  id uuid primary key default gen_random_uuid(),
  opportunity_id uuid not null references public.opportunities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  note text not null default '' check (char_length(note) <= 500),
  status text not null default 'received'
    check (status in ('received','reviewing','contacted','closed')),
  created_at timestamptz not null default now(),
  unique (opportunity_id, user_id)
);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.post_comments enable row level security;
alter table public.clubs enable row level security;
alter table public.opportunities enable row level security;
alter table public.opportunity_applications enable row level security;

-- Função privada para checar aprovação sem expor o campo ao navegador.
create or replace function public.is_guardian_approved()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.guardian_approved = true
  );
$$;
revoke all on function public.is_guardian_approved() from public;
grant execute on function public.is_guardian_approved() to authenticated;

-- Recriar políticas para permitir reexecutar este arquivo sem duplicar nomes.
drop policy if exists "profiles readable" on public.profiles;
drop policy if exists "user creates own profile" on public.profiles;
drop policy if exists "user updates own profile" on public.profiles;
drop policy if exists "approved posts readable" on public.posts;
drop policy if exists "user submits own pending post" on public.posts;
drop policy if exists "comments readable after approval" on public.post_comments;
drop policy if exists "user submits pending comment" on public.post_comments;
drop policy if exists "user reads own likes" on public.post_likes;
drop policy if exists "verified clubs readable" on public.clubs;
drop policy if exists "active opportunities readable" on public.opportunities;
drop policy if exists "users read own applications" on public.opportunity_applications;
drop policy if exists "approved users apply to active opportunities" on public.opportunity_applications;

create policy "profiles readable" on public.profiles for select
  using (guardian_approved = true or auth.uid() = id);
create policy "user updates own profile" on public.profiles for update
  using (auth.uid() = id) with check (auth.uid() = id);

-- Permissões por coluna: aprovação do responsável nunca é exposta ao navegador.
revoke all on public.profiles from anon, authenticated;
grant select (id, display_name, position, category, dominant_foot, bio, skills, created_at)
  on public.profiles to anon, authenticated;
grant update (display_name, position, category, dominant_foot, bio, skills)
  on public.profiles to authenticated;

create policy "approved posts readable" on public.posts for select
  using (moderation_status = 'approved');
create policy "user submits own pending post" on public.posts for insert
  with check (
    auth.uid() = user_id
    and moderation_status = 'pending'
    and public.is_guardian_approved()
  );

create policy "comments readable after approval" on public.post_comments for select
  using (moderation_status = 'approved');
create policy "user submits pending comment" on public.post_comments for insert
  with check (
    auth.uid() = user_id
    and moderation_status = 'pending'
    and public.is_guardian_approved()
    and exists (select 1 from public.posts p where p.id = post_id and p.moderation_status = 'approved')
  );

create policy "user reads own likes" on public.post_likes for select
  using (auth.uid() = user_id);

create policy "verified clubs readable" on public.clubs for select
  using (verified = true and is_active = true);
create policy "active opportunities readable" on public.opportunities for select
  using (
    is_active = true
    and exists (select 1 from public.clubs c where c.id = club_id and c.verified = true and c.is_active = true)
    and (closes_at is null or closes_at >= now())
  );
create policy "users read own applications" on public.opportunity_applications for select
  using (auth.uid() = user_id);
create policy "approved users apply to active opportunities" on public.opportunity_applications for insert
  with check (
    auth.uid() = user_id
    and public.is_guardian_approved()
    and exists (
      select 1 from public.opportunities o join public.clubs c on c.id = o.club_id
      where o.id = opportunity_id and o.is_active = true and c.verified = true and c.is_active = true
        and (o.closes_at is null or o.closes_at >= now())
    )
  );

-- Impede que o próprio usuário altere o campo de aprovação do responsável.
create or replace function public.protect_guardian_approval()
returns trigger language plpgsql set search_path = '' as $$
begin
  if auth.uid() is not null then
    new.guardian_approved := old.guardian_approved;
  end if;
  return new;
end;
$$;
drop trigger if exists protect_guardian_approval_trigger on public.profiles;
create trigger protect_guardian_approval_trigger before update on public.profiles
for each row execute function public.protect_guardian_approval();

-- O perfil nasce automaticamente após a confirmação/criação do cadastro.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(new.raw_user_meta_data->>'display_name',''), 'Novo atleta'))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- Curtidas são atualizadas por função controlada; o usuário não lê a lista de curtidas de terceiros.
create or replace function public.toggle_post_like(target_post uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  liked_now boolean;
  total_likes integer;
begin
  if auth.uid() is null then raise exception 'Entre na conta para curtir.'; end if;
  if not exists (select 1 from public.posts p where p.id = target_post and p.moderation_status = 'approved') then
    raise exception 'Publicação não encontrada.';
  end if;
  if exists (select 1 from public.post_likes l where l.post_id = target_post and l.user_id = auth.uid()) then
    delete from public.post_likes where post_id = target_post and user_id = auth.uid();
    liked_now := false;
  else
    insert into public.post_likes (post_id, user_id) values (target_post, auth.uid()) on conflict do nothing;
    liked_now := true;
  end if;
  select count(*)::integer into total_likes from public.post_likes where post_id = target_post;
  return jsonb_build_object('liked', liked_now, 'like_count', total_likes);
end;
$$;

create or replace function public.get_post_like_count(target_post uuid)
returns integer language sql stable security definer set search_path = '' as $$
  select count(*)::integer from public.post_likes l
  join public.posts p on p.id = l.post_id
  where l.post_id = target_post and p.moderation_status = 'approved';
$$;

revoke all on function public.toggle_post_like(uuid) from public;
grant execute on function public.toggle_post_like(uuid) to authenticated;
revoke all on function public.get_post_like_count(uuid) from public;
grant execute on function public.get_post_like_count(uuid) to anon, authenticated;
revoke insert, update, delete on public.post_likes from anon, authenticated;

-- STORAGE: crie manualmente um bucket chamado football-videos e deixe-o PRIVADO.
-- Estas políticas restringem o envio à própria pasta e a contas aprovadas.
drop policy if exists "upload own approved athlete videos" on storage.objects;
drop policy if exists "read approved videos or own uploads" on storage.objects;
drop policy if exists "delete own videos" on storage.objects;
create policy "upload own approved athlete videos" on storage.objects for insert to authenticated
  with check (
    bucket_id = 'football-videos'
    and (storage.foldername(name))[1] = auth.uid()::text
    and public.is_guardian_approved()
  );
create policy "read approved videos or own uploads" on storage.objects for select
  using (
    bucket_id = 'football-videos'
    and (
      exists (select 1 from public.posts p where p.video_path = name and p.moderation_status = 'approved')
      or (auth.uid() is not null and (storage.foldername(name))[1] = auth.uid()::text)
    )
  );
create policy "delete own videos" on storage.objects for delete to authenticated
  using (bucket_id = 'football-videos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Clubes e oportunidades são cadastrados/revisados pela administração no painel Supabase.
-- Não há formulário público para alguém fingir ser um clube ou publicar seletivas falsas.
